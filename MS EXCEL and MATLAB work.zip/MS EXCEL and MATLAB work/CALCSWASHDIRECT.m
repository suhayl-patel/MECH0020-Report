function [swash] = CALCSWASHDIRECT(R,rho,L,s,theta1,theta2,theta3)

theta1 = deg2rad(theta1);
theta2 = deg2rad(theta2);
theta3 = deg2rad(theta3);

t = optimvar('t', 2);
% t(1) = t_gamma
% t(2) = t_alpha

A_1 = -2*rho*sin(theta1) + 4*R*(t(1)/(1+t(1)^2));

B_1 = (-2*R*(rho*cos(theta1) + s)*(1-t(1)^2) - 4*rho*R*sin(theta1)*t(1))/(1+t(1)^2) + 2*rho*s*cos(theta1) - L^2 + rho^2 + s^2 + R^2;

A_2 = ((-R)/(1+t(1)^2))*(2*t(1) + 2*sqrt(3)*t(2)*((1-t(1)^2)/(1+t(1)^2))) - 2*rho*sin(theta2);

B_2 = (((-R)*(s + rho*cos(theta2)))/2)*(((1-t(1)^2)/(1+t(1)^2)) + 3*((1-t(2)^2)/(1+t(2)^2)) - 4*sqrt(3)*((t(1)*t(2))/((1+t(1)^2)*(1+t(2)^2)))) ...
+ 2*rho*R*sin(theta2)*(t(1)/(1+t(1)^2)) + 2*sqrt(3)*R*rho*sin(theta2)*t(2)*((1-t(1)^2)/((1+t(1)^2)*(1+t(2)^2))) + 2*s*rho*cos(theta2) - L^2 + rho^2 + s^2 + R^2;

A_3 = ((-R)/(1+t(1)^2))*(2*t(1) - 2*sqrt(3)*t(2)*((1-t(1)^2)/(1+t(1)^2))) - 2*rho*sin(theta3);

B_3 = (((-R)*(s + rho*cos(theta3)))/2)*(((1-t(1)^2)/(1+t(1)^2)) + 3*((1-t(2)^2)/(1+t(2)^2)) + 4*sqrt(3)*((t(1)*t(2))/((1+t(1)^2)*(1+t(2)^2)))) ...
+ 2*rho*R*sin(theta3)*(t(1)/(1+t(1)^2)) - 2*sqrt(3)*R*rho*sin(theta3)*t(2)*((1-t(1)^2)/((1+t(1)^2)*(1+t(2)^2))) + 2*s*rho*cos(theta3) - L^2 + rho^2 + s^2 + R^2;

eq1 = A_1*A_2*(B_1+B_2) - B_1*(A_2^2 + B_1) - B_2*(A_1^2 + B_2) + 2*B_1*B_2 == 0;

eq2 = A_2*A_3*(B_2+B_3) - B_2*(A_3^2 + B_2) - B_3*(A_2^2 + B_3) + 2*B_2*B_3 == 0;

prob = eqnproblem;
prob.Equations.eq1 = eq1;
prob.Equations.eq2 = eq2;

%show(prob)

t0.t = [0 0];
[sol,fval,exitflag] = solve(prob,t0);

gamma = 2*atan(sol.t(1));
alpha = 2*atan(sol.t(2));

%disp("Gamma = " + rad2deg(gamma))
%disp("Alpha = " + rad2deg(alpha))

A_1 = -2*rho*sin(theta1) + 4*R*(gamma/(1+gamma^2));

B_1 = (-2*R*(rho*cos(theta1) + s)*(1-gamma^2) - 4*rho*R*sin(theta1)*gamma)/(1+gamma^2) + 2*rho*s*cos(theta1) - L^2 + rho^2 + s^2 + R^2;

p = [1 A_1 B_1];
r = roots(p);
q = size(r);

for i = 1:2
    if r(i) > 0
        H = r(i);
    end
end

swash = [rad2deg(gamma), rad2deg(alpha), H];

end

